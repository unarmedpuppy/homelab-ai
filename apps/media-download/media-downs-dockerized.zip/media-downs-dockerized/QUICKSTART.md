# Media Download Stack - Quick Start

A complete Docker-based media download stack with VPN protection, indexers, and automation tools.

## What's Included

**VPN-Protected Downloads:**
- qBittorrent (torrents)
- NZBGet (Usenet) - or SABnzbd as alternative
- slskd (Soulseek music sharing)

**Indexers:**
- Prowlarr (unified indexer manager)
- Jackett (torrent indexer proxy)
- NZBHydra2 (Usenet aggregator)

**Automation:**
- Sonarr (TV shows)
- Radarr (movies)
- Lidarr (music)
- Bazarr (subtitles)
- LazyLibrarian (books)

**Management:**
- Overseerr (media requests)
- Calibre + Calibre-Web (ebooks)

## Setup Time: ~15-30 minutes

### 1. Prepare Your System

```bash
# Clone or extract this directory
cd media-download

# Create required directories
mkdir -p gluetun openvpn downloads/{torrents,nzb,soulseek}
```

### 2. Get VPN Config

**Option A: ProtonVPN**
1. Sign up for a ProtonVPN account
2. Download an OpenVPN config file
3. Rename it to `client.ovpn` and place in `openvpn/` directory

**Option B: Other VPN Provider**
1. Get your provider's `.ovpn` config file
2. Place it in `openvpn/client.ovpn`
3. If credentials required, create `gluetun/openvpn_credentials.conf`:
   ```
   username
   password
   ```

### 3. Configure Environment

```bash
# Copy example env file
cp env-example.txt .env

# Edit .env with your values:
# - PUID/PGID: Your user/group IDs (run `id -u` and `id -g` on Linux)
# - TZ: Your timezone
# - MEDIA_PATH: Where your media library lives
# - DOWNLOAD_PATH: Where downloads go temporarily
```

### 4. Start the Stack

```bash
# Start all services
docker compose up -d

# Check status
docker compose ps

# View logs if needed
docker compose logs -f
```

### 5. Access Services

| Service | URL | First Steps |
|---------|-----|-------------|
| Sonarr | http://localhost:8989 | Setup quality profiles, add paths |
| Radarr | http://localhost:7878 | Setup quality profiles, add paths |
| Lidarr | http://localhost:8686 | Setup quality profiles, add paths |
| Prowlarr | http://localhost:9696 | Add torrent/Usenet indexers |
| qBittorrent | http://localhost:8880 | Configure connection settings |
| NZBGet | http://localhost:6789 | Default: nzbget/tegbzn6789 |
| Overseerr | http://localhost:5055 | Create first user account |

Replace `localhost` with your server's IP if accessing from another machine.

## Next Steps

1. **Configure Prowlarr** - Add your torrent indexers and Usenet providers
2. **Connect Services** - In Sonarr/Radarr/Lidarr, add Prowlarr as indexer, qBittorrent/NZBGet as download client
3. **Set Quality Profiles** - Define what quality you want for TV/movies/music
4. **Import Media** - Add existing library to Sonarr/Radarr/Lidarr
5. **Start Requesting** - Use Overseerr to request new content

## Configuration Details

### Paths
All services use these environment variables from `.env`:
- `MEDIA_PATH` - Final media library location
- `DOWNLOAD_PATH` - Temporary download staging area

Example mount points:
- Sonarr: `${MEDIA_PATH}/tv:/tv`
- Radarr: `${MEDIA_PATH}/movies:/movies`
- Lidarr: `${MEDIA_PATH}/Music:/music`
- qBittorrent: `${DOWNLOAD_PATH}/torrents:/downloads`
- NZBGet: `${DOWNLOAD_PATH}/nzb:/downloads`

### VPN Protection
The following services route all traffic through VPN (kill switch enabled):
- qBittorrent
- NZBGet
- slskd

These services are NOT on VPN (they only search/organize):
- Sonarr, Radarr, Lidarr, Bazarr, Overseerr
- Prowlarr, Jackett, NZBHydra2

## Troubleshooting

**Services won't start?**
```bash
docker compose logs -f <service-name>
```

**Can't access web UI?**
- Check service is running: `docker compose ps`
- Try server IP instead of localhost
- Check firewall settings

**Downloads not working?**
- Verify VPN is connected: `docker compose logs gluetun`
- Check download client configuration (qBittorrent/NZBGet)
- Verify indexer connections

## Full Documentation

See `SETUP_GUIDE.md` for detailed setup instructions, troubleshooting, and configuration options.

## Requirements

- Docker & Docker Compose
- VPN subscription (or your own VPN config)
- ~20GB disk space minimum (much more recommended)
- Optional: Usenet provider for NZBGet/SABnzbd

## Support Resources

- [Sonarr Wiki](https://wiki.servarr.com/sonarr)
- [Radarr Wiki](https://wiki.servarr.com/radarr)
- [Prowlarr Wiki](https://wiki.servarr.com/prowlarr)
- [Gluetun (VPN)](https://github.com/qdm12/gluetun)

---

**Note:** This stack is designed for personal use. Ensure you have rights to download any content you obtain.

