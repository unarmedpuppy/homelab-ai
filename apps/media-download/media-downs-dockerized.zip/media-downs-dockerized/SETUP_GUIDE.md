# Media Download Stack - Setup Guide

This is a complete media download automation stack based on Docker Compose. It includes VPN-protected torrent/Usenet downloads, indexers, and media automation tools.

## Prerequisites

- Docker and Docker Compose installed
- A VPN subscription (ProtonVPN, OpenVPN, WireGuard, etc.) or your own OpenVPN config
- Optional: Usenet subscription for nzbget/sabnzbd
- Enough disk space for media storage

## Quick Start

### 1. Create Required Files

```bash
# Create directories
mkdir -p gluetun openvpn downloads/{torrents,nzb,sabnzbd,soulseek}

# Download or create your VPN config file
# Place it at: ./openvpn/client.ovpn
```

### 2. Create `.env` File

Create a `.env` file in the same directory as `docker-compose.yml`:

```bash
# User/Group IDs for file permissions
# On Linux, use your user ID: `id -u` and `id -g`
PUID=1000
PGID=1000

# Timezone
TZ=America/Chicago

# Media storage path
MEDIA_PATH=/path/to/media

# Download path (can be relative or absolute)
DOWNLOAD_PATH=./downloads
```

### 3. Setup VPN Configuration

This stack uses **Gluetun** as a VPN gateway with a kill switch. All download traffic (qBittorrent, NZBGet, slskd) is routed through the VPN.

#### Option A: ProtonVPN

1. Download ProtonVPN OpenVPN config from their web portal
2. Place the `.ovpn` file in `./openvpn/client.ovpn`
3. Create `./gluetun/openvpn_credentials.conf`:
   ```
   username
   password
   ```
4. Update the `gluetun` service environment:
   ```yaml
   environment:
     - VPN_SERVICE_PROVIDER=protonvpn
     - OPENVPN_USER=YOUR_USERNAME
     - OPENVPN_PASSWORD=YOUR_PASSWORD
     - PROTONVPN_TIER=2  # Free tier = 0, Basic = 1, Plus = 2
   ```

#### Option B: Custom OpenVPN Provider

1. Get your provider's `.ovpn` config file
2. Place it in `./openvpn/client.ovpn`
3. If credentials are required, create `./gluetun/openvpn_credentials.conf`:
   ```
   username
   password
   ```

See [Gluetun documentation](https://github.com/qdm12/gluetun) for all supported VPN providers.

### 4. Start the Stack

```bash
# Start all services (except SABnzbd which uses the 'alternative' profile)
docker compose up -d

# Start with SABnzbd instead of NZBGet
docker compose --profile alternative up -d
```

### 5. Access Services

Once running, access services at:

| Service | Port | URL (local) | Notes |
|---------|------|-------------|-------|
| qBittorrent | 8880 | http://localhost:8880 | Torrent download client |
| NZBGet | 6789 | http://localhost:6789 | Usenet download client |
| slskd | 5030 | http://localhost:5030 | Soulseek music client |
| Sonarr | 8989 | http://localhost:8989 | TV shows automation |
| Radarr | 7878 | http://localhost:7878 | Movies automation |
| Lidarr | 8686 | http://localhost:8686 | Music automation |
| Bazarr | 6767 | http://localhost:6767 | Subtitle downloader |
| Overseerr | 5055 | http://localhost:5055 | Media requests |
| Prowlarr | 9696 | http://localhost:9696 | Indexer manager |
| Jackett | 9117 | http://localhost:9117 | Torrent indexer |
| NZBHydra2 | 5076 | http://localhost:5076 | Usenet indexer |
| Calibre | 8085 | http://localhost:8085 | Ebook management |
| Calibre-Web | 8084 | http://localhost:8084 | Ebook web reader |
| LazyLibrarian | 8787 | http://localhost:8787 | Books automation |

Replace `localhost` with your server's IP if accessing remotely.

## Configuration Steps

### 1. Configure Indexers

Choose **ONE** of these approaches:

**Option A: Use Prowlarr (Recommended)**
- Access Prowlarr at http://localhost:9696
- Add your torrent indexers (Jackett-style) and Usenet indexers (NZBHydra2-style)
- Prowlarr will sync with Sonarr, Radarr, and Lidarr automatically

**Option B: Use Jackett + NZBHydra2**
- Configure Jackett (http://localhost:9117) for torrent indexers
- Configure NZBHydra2 (http://localhost:5076) for Usenet indexers
- Add both to Sonarr, Radarr, and Lidarr as indexer sources

### 2. Configure Download Clients

**For qBittorrent:**
- Access at http://localhost:8880
- Set up connection settings (defaults usually work)
- If using a tracker that requires whitelisting, note that you're behind a VPN

**For NZBGet:**
- Access at http://localhost:6789
- Default credentials: `nzbget` / `tegbzn6789` (change immediately!)
- Configure your Usenet provider settings

**For slskd:**
- Access at http://localhost:5030
- Set username/password
- **IMPORTANT**: You must share files to avoid being banned. The `/shared` volume is already mapped to your music library.

### 3. Configure Automation Services

**Sonarr (TV Shows):**
- Access at http://localhost:8989
- Add media root path: `/tv`
- Configure quality profiles
- Connect to download client (qBittorrent/NZBGet)
- Connect to indexer (Prowlarr/Jackett)

**Radarr (Movies):**
- Access at http://localhost:7878
- Add media root path: `/movies`
- Configure quality profiles
- Connect to download client and indexer

**Lidarr (Music):**
- Access at http://localhost:8686
- Add media root path: `/music`
- Configure quality profiles
- Connect to download client and indexer

**Bazarr (Subtitles):**
- Access at http://localhost:6767
- Connect to Sonarr and Radarr

**Overseerr (Media Requests):**
- Access at http://localhost:5055
- Set up first user account
- Connect to Sonarr and Radarr
- Overseerr will auto-import existing library

### 4. Optional: Add Traefik Reverse Proxy

If you want HTTPS and remote access with authentication:

1. Add Traefik labels back to services (see `docker-compose.yml` for examples)
2. Set up a reverse proxy (Traefik, Nginx Proxy Manager, etc.)
3. Configure SSL certificates (Let's Encrypt recommended)
4. Set up authentication (basic auth, OAuth2, etc.)

## Important Notes

### VPN Kill Switch

- **DO NOT disable the kill switch** - it prevents your real IP from leaking
- Services using `network_mode: "service:gluetun"` are protected:
  - qBittorrent
  - NZBGet
  - slskd
- Indexers (Jackett, NZBHydra2, Prowlarr) and automation (Sonarr, Radarr, etc.) are NOT on VPN
  - They only perform searches and API calls
  - Downloads happen through VPN-protected clients

### Soulseek Sharing

- **You must share files** to avoid being banned by the Soulseek network
- The `/shared` volume is mapped to your music library in slskd
- You can adjust the shared directory in the docker-compose file

### File Permissions

- All containers use `PUID` and `PGID` from `.env`
- Set these to your user/group IDs on the host
- This ensures files are accessible to your user account

### Storage Paths

- Adjust `MEDIA_PATH` in `.env` to point to your media library
- Adjust `DOWNLOAD_PATH` if you want downloads elsewhere
- Paths can be absolute or relative to the docker-compose directory

## Troubleshooting

### Services Not Starting

```bash
# Check logs
docker compose logs -f <service-name>

# Check VPN connection
docker compose logs gluetun

# Restart a service
docker compose restart <service-name>
```

### Can't Access Web UIs

- Ensure the service is running: `docker compose ps`
- Check if port is in use: `netstat -tulpn | grep <port>`
- Try accessing from server IP instead of localhost

### Downloads Not Working

- Check if VPN is connected: `docker compose logs gluetun`
- Verify download client configuration (NZBGet/qBittorrent)
- Check that Sonarr/Radarr can reach the download client
- Check indexer connections in Sonarr/Radarr

### VPN Issues

- Verify your VPN config file is valid
- Check credentials in `gluetun/openvpn_credentials.conf`
- Try different VPN server in your config
- See Gluetun logs: `docker compose logs -f gluetun`

## Directory Structure

```
media-download/
├── docker-compose.yml      # Main stack definition
├── .env                    # Environment variables (create this)
├── gluetun/
│   └── openvpn_credentials.conf  # VPN credentials (create if needed)
├── openvpn/
│   └── client.ovpn         # Your VPN config (create this)
├── downloads/
│   ├── torrents/           # qBittorrent downloads
│   ├── nzb/                # NZBGet downloads
│   ├── sabnzbd/            # SABnzbd downloads (alternative)
│   └── soulseek/           # slskd downloads
├── sonarr/config/
├── radarr/config/
├── lidarr/config/
├── bazarr/config/
├── overseerr/config/
├── prowlarr/config/
├── jackett/config/
├── nzbhydra2/config/
├── nzbhydra2/data/
├── qbittorrent/config/
├── nzbget/config/
├── slskd/config/
├── lazylibrarian/config/
├── calibre/config/
└── calibre-web/config/
```

## Useful Commands

```bash
# Start all services
docker compose up -d

# Stop all services
docker compose down

# Restart a service
docker compose restart sonarr

# View logs for a service
docker compose logs -f sonarr

# Update all images
docker compose pull
docker compose up -d

# Remove all containers (keeps data)
docker compose down

# Complete reset (DELETES ALL DATA - be careful!)
docker compose down -v
rm -rf */config
```

## Resources

- [Gluetun Documentation](https://github.com/qdm12/gluetun)
- [Sonarr Wiki](https://wiki.servarr.com/sonarr)
- [Radarr Wiki](https://wiki.servarr.com/radarr)
- [Lidarr Wiki](https://wiki.servarr.com/lidarr)
- [Prowlarr Wiki](https://wiki.servarr.com/prowlarr)
- [Bazarr Documentation](https://wiki.bazarr.media)

## License

This is provided as-is for personal use. Please ensure you have the right to download and use any content you obtain through this setup.

